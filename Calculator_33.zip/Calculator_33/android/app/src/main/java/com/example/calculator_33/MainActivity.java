package com.example.calculator_33;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
